module.exports = {
  plugins: {
    autoprefixer: {},
  },
}
