const noticeType = {
    'text': '文本',
    'video': '直播',
};
  
export default noticeType