
const comp = {
  'sf': '顺丰',
  'sto': '申通',
  'yt': '圆通',
  'yd': '韵达',
  'tt': '天天',
  'ems': 'EMS',
  'zto': '中通',
  'ht': '汇通',
  'qf': '全峰',
  'db': '德邦',
  'gt': '国通',
  'rfd': '如风达',
  'jd': '京东',
  'zjs': '宅急送',
  'youzheng': '邮政快递',
  'bsky': '百世'
}

export default comp