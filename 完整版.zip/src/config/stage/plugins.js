// 本文件是自动生成, 请勿修改

const pluginsConfig = [
]

export default pluginsConfig
